(function () {
  document.getElementById('pkg-direct-dep').innerHTML = 'pkg-direct-dep';
})()